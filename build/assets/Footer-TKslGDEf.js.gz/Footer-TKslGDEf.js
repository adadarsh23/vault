import{a as e}from"./rolldown-runtime-CNC7AqOf.js";import{Bt as t,gr as n}from"./icons-BP1Rw5si.js";import{gr as r}from"./react-framework-exhox5sd.js";import{o as i}from"./markdown-DMdIYBS6.js";import{a,t as o}from"./motion-7iN2eLLl.js";var s=e(n(),1),c=i(),l=e=>({hidden:{opacity:0},visible:{opacity:1,transition:{staggerChildren:e?0:.05,delayChildren:e?0:.15}}}),u=e=>({hidden:{opacity:0,y:e?0:60},visible:{opacity:.2,y:0,transition:{duration:e?0:.9,ease:[.22,1,.36,1]}}}),d=e=>({hidden:{opacity:0,y:e?0:20},visible:{opacity:1,y:0,transition:{duration:e?0:.5,ease:`easeOut`}}}),f=(0,s.memo)(()=>{let e=o();return(0,c.jsxs)(`footer`,{className:`relative z-10 mt-24 sm:mt-28 lg:mt-32 pb-10 overflow-hidden`,children:[(0,c.jsxs)(`div`,{className:`absolute inset-0 flex items-end justify-center pointer-events-none select-none -z-10 overflow-hidden`,"aria-hidden":`true`,children:[(0,c.jsx)(a.div,{initial:`hidden`,whileInView:`visible`,viewport:{once:!0,margin:`-80px`},variants:l(!!e),className:`
            flex items-end justify-center
            -space-x-[0.04em]
            translate-y-[35%] sm:translate-y-[15%] lg:translate-y-[12%]
            w-full h-full
            will-change-transform
          `,children:Array.from(`VAULT`).map((t,n)=>(0,c.jsx)(a.span,{variants:u(!!e),initial:{opacity:0,y:100},animate:{opacity:.2,y:0},transition:{duration:e?0:1.2,delay:n*.08,ease:[.22,1,.36,1]},whileHover:e?{}:{opacity:.25,y:-14,scale:1.03},className:`
          text-[clamp(8rem,28vw,35rem)]
          font-black
          leading-none
          text-white
          whitespace-nowrap
          tracking-tighter
        `,style:{filter:`blur(0.5px)`},children:t},n))}),(0,c.jsx)(`div`,{className:`absolute bottom-0 left-0 right-0 h-80 bg-gradient-to-t from-indigo-500/20 via-fuchsia-500/15 via-cyan-400/10 to-transparent blur-[120px]`}),(0,c.jsx)(`div`,{className:`absolute bottom-0 left-1/2 -translate-x-1/2 w-[60%] h-60 rounded-full bg-white/5 blur-[120px]`}),(0,c.jsx)(`div`,{className:`absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_45%,rgba(0,0,0,0.3)_100%)]`}),(0,c.jsx)(`div`,{className:`absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/30`}),(0,c.jsx)(`div`,{className:`absolute inset-0 opacity-[0.03] mix-blend-soft-light bg-[radial-gradient(circle_at_center,white_1px,transparent_1px)] [background-size:22px_22px]`}),(0,c.jsx)(`div`,{className:`absolute inset-0 opacity-[0.025] bg-[url('/noise.png')] mix-blend-overlay`})]}),(0,c.jsx)(`div`,{className:`mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10`,children:(0,c.jsxs)(a.div,{initial:`hidden`,whileInView:`visible`,viewport:{once:!0},variants:d(!!e),className:`pt-14 sm:pt-16 lg:pt-20 border-t border-white/10`,children:[(0,c.jsxs)(`div`,{className:`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-x-8 gap-y-12`,children:[(0,c.jsx)(`div`,{className:`lg:col-span-5 flex flex-col items-center sm:items-start text-center sm:text-left`,children:(0,c.jsxs)(`div`,{className:`flex items-center gap-3 mb-5`,children:[(0,c.jsx)(a.div,{whileHover:e?{}:{scale:1.05,rotate:4},className:`p-2 rounded-xl bg-white text-black shadow-lg`,children:(0,c.jsx)(t,{className:`w-7 h-7`})}),(0,c.jsx)(`span`,{className:`text-xl sm:text-2xl font-semibold text-white tracking-tight`,children:`Vault`})]})}),(0,c.jsx)(`div`,{className:`lg:col-span-7 flex flex-col items-center sm:items-end`,children:(0,c.jsxs)(`div`,{className:`w-full max-w-xs sm:max-w-none flex flex-col items-center sm:items-end`,children:[(0,c.jsx)(`h2`,{className:`text-[11px] font-semibold uppercase tracking-[0.2em] text-white/40 mb-4`,children:`Platform & Legal`}),(0,c.jsxs)(`nav`,{className:`flex flex-col gap-2 w-full items-center sm:items-end`,children:[(0,c.jsx)(r,{to:`/contact`,className:`
                      w-full sm:w-auto
                      px-4 py-2 sm:px-0 sm:py-0
                      text-center sm:text-right
                      text-white/70 text-sm
                      rounded-lg
                      transition-all duration-200
                      hover:text-white
                      focus:outline-none focus:ring-2 focus:ring-white/20
                    `,children:`Contact Us`}),(0,c.jsx)(r,{to:`/legal#license`,className:`
                      w-full sm:w-auto
                      px-4 py-2 sm:px-0 sm:py-0
                      text-center sm:text-right
                      text-white/70 text-sm
                      rounded-lg
                      transition-all duration-200
                      hover:text-white
                      focus:outline-none focus:ring-2 focus:ring-white/20
                    `,children:`License`}),(0,c.jsx)(r,{to:`/legal#privacy`,className:`
                      w-full sm:w-auto
                      px-4 py-2 sm:px-0 sm:py-0
                      text-center sm:text-right
                      text-white/70 text-sm
                      rounded-lg
                      transition-all duration-200
                      hover:text-white
                      focus:outline-none focus:ring-2 focus:ring-white/20
                    `,children:`Privacy Policy`})]})]})})]}),(0,c.jsxs)(`div`,{className:`mt-14 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4`,children:[(0,c.jsxs)(`p`,{className:`text-white/40 text-xs`,children:[`© `,new Date().getFullYear(),` Vault. All rights reserved.`]}),(0,c.jsx)(`span`,{className:`text-white/30 text-[10px] uppercase tracking-[0.2em] font-medium`,children:`Data Encrypted Vault`})]})]})})]})});f.displayName=`Footer`;export{f as Footer};
//# sourceMappingURL=Footer-TKslGDEf.js.map