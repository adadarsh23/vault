# Code Memory Summary

Generated: 2026-08-25T18:30:05.004Z
Schema: code-memory-index/v5

## Totals
- Files Indexed: 527
- Lines Indexed: 153723
- Symbols: 3150
- Imports: 2145

## Changes
- Added: 63
- Removed: 10
- Changed: 337

## Risk Summary
- Critical: 13
- High: 51
- Medium: 77
- Low: 386
