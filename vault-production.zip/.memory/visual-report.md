# Code Memory Visual Report

Generated: 2026-08-25T18:30:05.004Z
Schema: code-memory-index/v5
Detail Level: summary
Files in Visual: 527

## Totals
- Indexed Files: 527
- Lines: 153723
- Symbols: 3150
- Imports: 2145

## Risk
- Critical: 13
- High: 51
- Medium: 77
- Low: 386
