import * as React from "react"
import { cn } from "../../lib/utils"

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          "flex h-10 w-full rounded-md border border-card-border bg-card-bg px-3 py-2 text-base md:text-sm text-text ring-offset-bg file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-text/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-text/20 disabled:cursor-not-allowed disabled:opacity-50 transition-colors",
          className
        )}
        ref={ref}
        {...props}
      />
    )
  }
)
Input.displayName = "Input"

export { Input }
