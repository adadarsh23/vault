export const EmergencyAccessCard = () => null;
