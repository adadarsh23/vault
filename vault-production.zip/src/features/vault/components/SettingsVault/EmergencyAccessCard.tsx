export const EmergencyAccessCard = () => null
