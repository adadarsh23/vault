import { VaultItem } from './storage';

export interface FuzzyResult {
  score: number;
  matches: number[];
}

export interface TextPart {
  text: string;
  isMatch: boolean;
}

export interface FuzzySearchResult {
  item: VaultItem;
  score: number;
  titleMatches: number[];
  folderMatches: number[];
  typeMatches: number[];
  tagMatches: { tag: string; matches: number[] }[];
  transcriptMatches?: number[];
  transcriptSnippet?: string;
}

/**
 * Perform a subsequence fuzzy match of query against text.
 * Returns score and indices of matched characters in text, or null if no match.
 */
export function fuzzyMatch(query: string, text: string): FuzzyResult | null {
  const q = query.toLowerCase();
  const t = text.toLowerCase();

  if (q.length === 0) {
    return { score: 0, matches: [] };
  }

  const qLen = q.length;
  const tLen = t.length;

  if (qLen > tLen) {
    return null;
  }

  // Fast early-rejection check: verify all characters of query appear sequentially in text
  let qScan = 0;
  for (let tScan = 0; tScan < tLen && qScan < qLen; tScan++) {
    if (t[tScan] === q[qScan]) {
      qScan++;
    }
  }
  if (qScan < qLen) {
    return null;
  }

  // Flat 1D memoization table: stores the best FuzzyResult or null
  const memo: (FuzzyResult | null | undefined)[] = new Array(qLen * tLen);

  function match(qIdx: number, tIdx: number): FuzzyResult | null {
    if (qIdx === qLen) {
      return { score: 0, matches: [] };
    }
    if (tIdx === tLen) {
      return null;
    }

    const memoKey = qIdx * tLen + tIdx;
    if (memo[memoKey] !== undefined) {
      return memo[memoKey];
    }

    const char = q[qIdx];
    let bestResult: FuzzyResult | null = null;

    // Search for occurrences of char starting from tIdx
    const remainingQ = qLen - qIdx;
    const maxSearchIdx = tLen - remainingQ;

    for (let i = tIdx; i <= maxSearchIdx; i++) {
      if (t[i] === char) {
        const next = match(qIdx + 1, i + 1);
        if (next !== null) {
          let score = 10; // base score for a matching character

          // Bonus: Consecutive character match
          if (qIdx > 0 && i === tIdx) {
            score += 15;
          }

          // Bonus: Match at word start / word boundary
          const prevChar = i > 0 ? text[i - 1] : '';
          const isWordStart =
            i === 0 ||
            prevChar === ' ' ||
            prevChar === '-' ||
            prevChar === '_' ||
            prevChar === '/' ||
            prevChar === '\\' ||
            prevChar === '.';
          if (isWordStart) {
            score += 20;
          }

          // Bonus: CamelCase transition match (e.g. 'C' in 'camelCase')
          const isCamelStart =
            i > 0 &&
            text[i] !== t[i] && // original is uppercase
            text[i - 1] === t[i - 1]; // previous was lowercase
          if (isCamelStart) {
            score += 15;
          }

          // Penalty: Gap from previous match
          if (qIdx > 0 && i > tIdx) {
            const gap = i - tIdx;
            score -= gap * 2;
          }

          // Penalty: Distance from start of the text (helps matches at beginning of title rank higher)
          if (qIdx === 0) {
            score -= i * 0.5;
          }

          const totalScore = score + next.score;
          const matches = [i, ...next.matches];

          if (bestResult === null || totalScore > bestResult.score) {
            bestResult = { score: totalScore, matches };
          }
        }
      }
    }

    memo[memoKey] = bestResult;
    return bestResult;
  }

  const result = match(0, 0);
  if (result === null) return null;

  // Apply a small penalty for overall text length so shorter strings matching the query rank higher
  result.score -= tLen * 0.1;
  return result;
}

/**
 * Splits text into highlighted/unhighlighted segments for UI rendering.
 * Merges consecutive matched or unmatched character ranges.
 */
export function getHighlightedParts(text: string, matches: number[]): TextPart[] {
  if (!matches || matches.length === 0 || !text) {
    return [{ text, isMatch: false }];
  }

  const parts: TextPart[] = [];
  const matchSet = new Set(matches);
  let currentPart = { text: text[0], isMatch: matchSet.has(0) };

  for (let i = 1; i < text.length; i++) {
    const isMatch = matchSet.has(i);
    if (isMatch === currentPart.isMatch) {
      currentPart.text += text[i];
    } else {
      parts.push(currentPart);
      currentPart = { text: text[i], isMatch };
    }
  }
  parts.push(currentPart);

  return parts;
}

/**
 * Extracts a concise snippet of transcript text around the matched query.
 */
export function getTranscriptSnippet(
  transcript: string,
  query: string,
  maxLength = 80,
): { snippet: string; matches: number[] } {
  if (!transcript || !query) return { snippet: '', matches: [] };

  const lowerTranscript = transcript.toLowerCase();
  const lowerQuery = query.toLowerCase().trim();
  const directIndex = lowerTranscript.indexOf(lowerQuery);

  let start = 0;
  if (directIndex >= 0) {
    start = Math.max(0, directIndex - Math.floor((maxLength - lowerQuery.length) / 2));
  }
  let end = Math.min(transcript.length, start + maxLength);
  if (end - start < maxLength && start > 0) {
    start = Math.max(0, end - maxLength);
  }

  let snippet = transcript.slice(start, end);
  if (start > 0) snippet = '...' + snippet;
  if (end < transcript.length) snippet = snippet + '...';

  // Highlight query within the snippet
  const snippetLower = snippet.toLowerCase();
  const matchResult = fuzzyMatch(lowerQuery, snippetLower);

  return {
    snippet,
    matches: matchResult ? matchResult.matches : [],
  };
}

/**
 * Searches across all vault items using a client-side fuzzy matching index.
 * Indexes title, folder, type, tags, and encrypted speech transcripts.
 */
export function searchVaultItems(
  items: VaultItem[],
  query: string,
  typeConfigs: Record<string, any>,
): FuzzySearchResult[] {
  const trimmed = query.trim();
  if (!trimmed) {
    // Default: Sort by pinned first, then updatedAt desc, and return everything
    return items
      .filter((item) => !!typeConfigs[item.type])
      .map((item) => ({
        item,
        score: 0,
        titleMatches: [],
        folderMatches: [],
        typeMatches: [],
        tagMatches: [],
      }));
  }

  const isTagSearch = trimmed.startsWith('#');
  const actualQuery = isTagSearch ? trimmed.slice(1) : trimmed;

  if (isTagSearch && !actualQuery) {
    // Show all items that have tags
    return items
      .filter((item) => {
        if (!typeConfigs[item.type]) return false;
        const tags = (item.metadata?.tags as string[]) || [];
        return tags.length > 0;
      })
      .map((item) => ({
        item,
        score: 1,
        titleMatches: [],
        folderMatches: [],
        typeMatches: [],
        tagMatches: ((item.metadata?.tags as string[]) || []).map((t) => ({
          tag: t,
          matches: [],
        })),
      }));
  }

  const results: FuzzySearchResult[] = [];
  const actualQueryLower = actualQuery.toLowerCase();

  for (const item of items) {
    if (!typeConfigs[item.type]) continue;

    const tags = (item.metadata?.tags as string[]) || [];

    if (isTagSearch) {
      const tagMatches: { tag: string; matches: number[] }[] = [];
      let bestTagScore = -Infinity;

      for (const tag of tags) {
        const matchResult = fuzzyMatch(actualQuery, tag);
        if (matchResult) {
          tagMatches.push({ tag, matches: matchResult.matches });
          if (matchResult.score > bestTagScore) {
            bestTagScore = matchResult.score;
          }
        }
      }

      if (tagMatches.length > 0) {
        results.push({
          item,
          score: bestTagScore,
          titleMatches: [],
          folderMatches: [],
          typeMatches: [],
          tagMatches,
        });
      }
    } else {
      const titleMatch = fuzzyMatch(actualQuery, item.title);
      const folderMatch = item.folder ? fuzzyMatch(actualQuery, item.folder) : null;
      const typeLabel = typeConfigs[item.type]?.label || item.type;
      const typeMatch = fuzzyMatch(actualQuery, typeLabel);

      const tagMatches: { tag: string; matches: number[] }[] = [];
      let bestTagScore = -Infinity;

      for (const tag of tags) {
        const matchResult = fuzzyMatch(actualQuery, tag);
        if (matchResult) {
          tagMatches.push({ tag, matches: matchResult.matches });
          if (matchResult.score > bestTagScore) {
            bestTagScore = matchResult.score;
          }
        }
      }

      // Search speech transcript metadata for audio memos and videos
      const transcript =
        typeof item.metadata?.transcript === 'string' ? item.metadata.transcript : '';
      const transcriptLower = transcript.toLowerCase();
      const directTranscriptIndex = transcriptLower.indexOf(actualQueryLower);
      const transcriptFuzzy =
        directTranscriptIndex === -1 && transcript.length > 0
          ? fuzzyMatch(actualQuery, transcript.slice(0, 300))
          : null;

      let transcriptScore = 0;
      let snippetData: { snippet: string; matches: number[] } | null = null;

      if (directTranscriptIndex >= 0) {
        // Direct word/substring match in transcript is high confidence
        transcriptScore = 35 + actualQuery.length * 5;
        snippetData = getTranscriptSnippet(transcript, actualQuery);
      } else if (transcriptFuzzy) {
        transcriptScore = transcriptFuzzy.score * 0.85;
        snippetData = getTranscriptSnippet(transcript, actualQuery);
      }

      const hasMatch =
        titleMatch || folderMatch || typeMatch || tagMatches.length > 0 || transcriptScore > 0;

      if (hasMatch) {
        const scores: number[] = [];
        if (titleMatch) scores.push(titleMatch.score);
        if (folderMatch) scores.push(folderMatch.score * 0.8);
        if (typeMatch) scores.push(typeMatch.score * 0.6);
        if (tagMatches.length > 0) scores.push(bestTagScore * 0.7);
        if (transcriptScore > 0) scores.push(transcriptScore);

        const maxScore = Math.max(...scores);

        results.push({
          item,
          score: maxScore,
          titleMatches: titleMatch ? titleMatch.matches : [],
          folderMatches: folderMatch ? folderMatch.matches : [],
          typeMatches: typeMatch ? typeMatch.matches : [],
          tagMatches,
          transcriptMatches: snippetData ? snippetData.matches : undefined,
          transcriptSnippet: snippetData ? snippetData.snippet : undefined,
        });
      }
    }
  }

  return results.sort((a, b) => b.score - a.score);
}
