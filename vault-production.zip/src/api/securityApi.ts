export const securityApi = {}
