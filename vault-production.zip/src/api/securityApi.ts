export const securityApi = {};
