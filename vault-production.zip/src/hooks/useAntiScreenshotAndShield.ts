import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { toast } from 'sonner';

export interface AntiScreenshotShieldOptions {
  isTabSwitchShieldEnabled?: boolean;
  isPrintBlockingEnabled?: boolean;
  isViewingSensitiveMedia?: boolean;
  onShieldChange?: (isShielded: boolean) => void;
  customShieldMessage?: string;
}

export interface AntiScreenshotShieldState {
  isShieldActive: boolean;
  isPrintBlocked: boolean;
  shieldReason: 'tab-hidden' | 'window-blurred' | 'print-attempt' | 'screenshot-attempt' | null;
  deactivateShield: () => void;
  triggerManualShield: (durationMs?: number) => void;
}

/**
 * useAntiScreenshotAndShield
 * Hook to protect media and sensitive screens from:
 * 1. Printing (Ctrl+P, window.print, browser print menus)
 * 2. Tab/App switcher previews (visibilitychange, blur)
 * 3. Screenshots (PrintScreen key captures)
 */
export const useAntiScreenshotAndShield = ({
  isTabSwitchShieldEnabled = true,
  isPrintBlockingEnabled = true,
  isViewingSensitiveMedia = true,
  onShieldChange,
  customShieldMessage,
}: AntiScreenshotShieldOptions = {}): AntiScreenshotShieldState => {
  const [isShieldActive, setIsShieldActive] = useState(false);
  const [isPrintBlocked, setIsPrintBlocked] = useState(false);
  const [shieldReason, setShieldReason] = useState<AntiScreenshotShieldState['shieldReason']>(null);

  const shieldChangeCallbackRef = useRef(onShieldChange);
  useEffect(() => {
    shieldChangeCallbackRef.current = onShieldChange;
  }, [onShieldChange]);

  const timeoutsRef = useRef<Set<ReturnType<typeof setTimeout>>>(new Set());

  const clearPendingTimeouts = useCallback(() => {
    timeoutsRef.current.forEach((id) => clearTimeout(id));
    timeoutsRef.current.clear();
  }, []);

  const setShieldState = useCallback(
    (active: boolean, reason: AntiScreenshotShieldState['shieldReason'] = null) => {
      setIsShieldActive(active);
      setShieldReason(active ? reason : null);
      shieldChangeCallbackRef.current?.(active);
    },
    [],
  );

  const deactivateShield = useCallback(() => {
    clearPendingTimeouts();
    setShieldState(false, null);
  }, [clearPendingTimeouts, setShieldState]);

  const triggerManualShield = useCallback(
    (durationMs = 2000) => {
      clearPendingTimeouts();
      setShieldState(true, 'screenshot-attempt');
      if (durationMs > 0) {
        const timerId = setTimeout(() => {
          timeoutsRef.current.delete(timerId);
          setShieldState(false, null);
        }, durationMs);
        timeoutsRef.current.add(timerId);
      }
    },
    [clearPendingTimeouts, setShieldState],
  );

  // Clear all pending timeouts on unmount
  useEffect(() => {
    return () => {
      clearPendingTimeouts();
    };
  }, [clearPendingTimeouts]);

  useEffect(() => {
    if (typeof window === 'undefined' || typeof document === 'undefined') return;

    // 1. Tab Switch & OS Multitasking Preview Auto-Shield
    const handleVisibilityChange = () => {
      if (!isTabSwitchShieldEnabled || !isViewingSensitiveMedia) return;
      if (typeof document !== 'undefined' && document.pictureInPictureElement) return;

      if (document.visibilityState === 'hidden') {
        setShieldState(true, 'tab-hidden');
      } else if (document.visibilityState === 'visible') {
        // Quick unlock when returning
        setShieldState(false, null);
      }
    };

    const handleWindowBlur = () => {
      if (!isTabSwitchShieldEnabled || !isViewingSensitiveMedia) return;
      if (typeof document !== 'undefined' && document.pictureInPictureElement) return;

      // Do NOT trigger shield on touch / mobile devices:
      // Mobile browsers (iOS Safari, Android Chrome) trigger window blur on touch scrolls,
      // virtual keyboards, URL bar adjustments, and modal interactions.
      // Mobile app switching is already reliably handled by document 'visibilitychange'.
      const isTouchOrMobile =
        typeof window !== 'undefined' &&
        ('ontouchstart' in window ||
          (typeof navigator !== 'undefined' && navigator.maxTouchPoints > 0) ||
          window.innerWidth <= 768);
      if (isTouchOrMobile) return;

      // If blur was caused by user interacting with an iframe (PDF viewer, doc viewer) or inside preview
      if (
        document.activeElement &&
        (document.activeElement.tagName === 'IFRAME' ||
          document.activeElement.closest?.('.doc-preview-content') ||
          document.activeElement.closest?.('.pdf-viewer-container'))
      ) {
        return;
      }

      setShieldState(true, 'window-blurred');
    };

    const handleWindowFocus = () => {
      setShieldState(false, null);
    };

    // 2. Print Interception Handlers
    const handleBeforePrint = () => {
      if (!isPrintBlockingEnabled || !isViewingSensitiveMedia) return;
      setIsPrintBlocked(true);
      setShieldState(true, 'print-attempt');
    };

    const handleAfterPrint = () => {
      setIsPrintBlocked(false);
      setShieldState(false, null);
    };

    // 3. Keyboard Shortcut Interception (Ctrl+P, Cmd+P, PrintScreen)
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isViewingSensitiveMedia) return;

      // Intercept Ctrl+P / Cmd+P (Print & Save as PDF)
      if (isPrintBlockingEnabled && (e.ctrlKey || e.metaKey) && (e.key === 'p' || e.key === 'P')) {
        e.preventDefault();
        e.stopPropagation();
        setShieldState(true, 'print-attempt');
        toast.error(
          customShieldMessage ||
            '⚠️ Printing and PDF export are blocked for protected vault media.',
          {
            duration: 3500,
          },
        );
        const timerId = setTimeout(() => {
          timeoutsRef.current.delete(timerId);
          setShieldState(false, null);
        }, 1200);
        timeoutsRef.current.add(timerId);
        return;
      }

      // Intercept PrintScreen key
      if (isPrintBlockingEnabled && (e.key === 'PrintScreen' || e.keyCode === 44)) {
        setShieldState(true, 'screenshot-attempt');
        toast.info('🛡️ Security Shield activated against screen capture.', {
          duration: 2500,
        });
        const timerId = setTimeout(() => {
          timeoutsRef.current.delete(timerId);
          setShieldState(false, null);
        }, 1500);
        timeoutsRef.current.add(timerId);
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);
    window.addEventListener('beforeprint', handleBeforePrint);
    window.addEventListener('afterprint', handleAfterPrint);
    window.addEventListener('keydown', handleKeyDown, true);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
      window.removeEventListener('beforeprint', handleBeforePrint);
      window.removeEventListener('afterprint', handleAfterPrint);
      window.removeEventListener('keydown', handleKeyDown, true);
    };
  }, [
    isTabSwitchShieldEnabled,
    isPrintBlockingEnabled,
    isViewingSensitiveMedia,
    customShieldMessage,
    setShieldState,
  ]);

  return useMemo(
    () => ({
      isShieldActive,
      isPrintBlocked,
      shieldReason,
      deactivateShield,
      triggerManualShield,
    }),
    [isShieldActive, isPrintBlocked, shieldReason, deactivateShield, triggerManualShield],
  );
};
